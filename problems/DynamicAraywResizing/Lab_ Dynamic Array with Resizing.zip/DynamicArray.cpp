#include "DynamicArray.h"

DynamicArray::DynamicArray()
{
   //complete
}

DynamicArray::DynamicArray(int s)
{
   //complete
}

void DynamicArray::addElement(int val)
{
    
    if(/*check if array if full*/) {
       //create a temporary dynamic array
       
       
       //copy element from arr to temporary array
        


      //delete arr
      
      
      //double size of array
      
      
      //allocate new memory for arr


      //copy elements from temporary array to arr
      
      
      //delete temporary array
    }
    
    //add new element to array and update length
    
}

int DynamicArray::getLength()
{
   //compelte
}

int DynamicArray::getElement(int pos)
{
   //complete
}

int DynamicArray::getSize()
{ 
   //complete
}

DynamicArray::~DynamicArray() { delete [] arr;}


